DINERO AI — 110,000 formulations question/réponse locales.
Aucune API nécessaire. Pour GitHub Pages, mets index.html à la racine du dépôt.
