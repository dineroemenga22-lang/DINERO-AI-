DINERO AI — 100 000 formulations question/réponse locales.
Le site est dans index.html. Pour GitHub Pages, mets index.html à la racine du dépôt.
